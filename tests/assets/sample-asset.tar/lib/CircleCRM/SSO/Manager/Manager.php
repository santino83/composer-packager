<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Manager;

use CircleCRM\SSO\Component\AbstractComponent;
use CircleCRM\SSO\Protocol\ProtocolInterface;
use CircleCRM\SSO\Security\Core\Authentication\Token\SsoToken;
use CircleCRM\SSO\Security\Core\User\SsoUser;
use CircleCRM\SSO\Server\ServerInterface;
use CircleCRM\SSO\Validation\ValidationInterface;
use GuzzleHttp\ClientInterface;
use Psr\Log\LoggerInterface;
use Psr\Log\LogLevel;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AuthenticationException;

/**
 * Manager Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class Manager extends AbstractComponent implements ManagerInterface
{

    /**
     *
     * @var ServerInterface
     */
    private $server;

    /**
     *
     * @var ProtocolInterface
     */
    private $protocol;

    /**
     *
     * @var ClientInterface
     */
    private $client;

    /**
     * 
     * @param string $id
     * @param ServerInterface $server
     * @param ProtocolInterface $protocol
     * @param ClientInterface $client
     * @param array $config
     * @param LoggerInterface $logger
     */
    public function __construct($id, 
            ServerInterface $server, 
            ProtocolInterface $protocol, 
            ClientInterface $client,
            array $config = [], 
            LoggerInterface $logger = null)
    {
        parent::__construct($id, $config, $logger);
        $this->server = $server;
        $this->protocol = $protocol;
        $this->client = $client;
    }

    public function authenticate($username, $secret)
    {
        $this->log('Manager::authenticate username ' . $username);
        $user = $this->protocol->authenticate($username, $secret, $this->server, $this->client);

        if (!$user) {
            $this->log("user data not validated by the sso server", LogLevel::ERROR);
            throw new AuthenticationException();
        }

        return $user;
    }

    /**
     * 
     * @param Request $request
     * @param string $providerKey
     * @return SsoToken
     */
    public function createToken(Request $request, $providerKey)
    {
        $ticket = $this->protocol->extractCredentials($request);
        $this->log("Manager::Creating token with ticket " . $ticket);
        return new SsoToken($ticket, $providerKey);
    }

    /**
     * 
     * @return ProtocolInterface
     */
    public function getProtocol()
    {
        return $this->protocol;
    }

    /**
     * 
     * @return ServerInterface
     */
    public function getServer()
    {
        return $this->server;
    }

    /**
     * 
     * @param mixed $credentials
     * @return ValidationInterface
     */
    public function validateCredentials($credentials)
    {
        $this->log("Manager::Validating credentials: " . $credentials);
        $request = $this->server->getValidationHttpRequest($credentials);

        $response = $this->client->send($request);

        return $this->protocol->validateResponse($response, $credentials);
    }

    /**
     * 
     * @param ValidationInterface $validation
     * @return SsoUser
     * @throws AuthenticationException
     */
    public function createUser(ValidationInterface $validation)
    {
        if (!$validation->isSuccess()) {
            $this->log("user data not validated by the sso server", LogLevel::ERROR);
            throw new AuthenticationException();
        }

        return $this->protocol->extractUser($validation);
    }

    public function deserializeUser($json)
    {
        return $this->protocol->getUserDeserializer()->deserialize($json);
    }

    public function serializeUser(SsoUser $user)
    {
        return $this->protocol->getUserSerializer()->serialize($user);
    }

}
