<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Component;

use Psr\Log\LoggerInterface;
use Psr\Log\LogLevel;

/**
 * AbstractComponent Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
abstract class AbstractComponent implements ComponentInterface {
    
    /**
     *
     * @var array
     */
    private $config;
    
    /**
     *
     * @var string
     */
    private $id;
    
    /**
     *
     * @var LoggerInterface
     */
    private $logger;
    
    /**
     * 
     * @param string $id
     * @param array $config
     * @param LoggerInterface $logger
     */
    public function __construct($id, array $config = [], LoggerInterface $logger = null)
    {
        $this->id = $id;
        $this->logger = $logger;
        $this->setConfig($config);
    }
    
    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }
    
    /**
     * 
     * @return LoggerInterface
     */
    public function getLogger()
    {
        return $this->logger;
    }
    
    /**
     * 
     * @return array
     */
    public function getConfig()
    {
        return $this->config;
    }

    /**
     * 
     * @param array $config
     * @return AbstractComponent
     */
    public function setConfig(array $config)
    {
        $this->config = $config;
        
        return $this;
    }
    
    /**
     * 
     * Gets a configuration param by name
     * 
     * @param string $name
     * @return mixed|null
     */
    public function getConfigurationParam($name, $default = null)
    {
        return array_key_exists($name, $this->config) ? $this->config[$name] : $default;
    }
    
    /**
     * 
     * @param string $name
     * @param mixed $value
     */
    public function setConfigurationParam($name, $value)
    {
        $this->config[$name] = $value;
    }
    
    protected function log($message, $level = LogLevel::DEBUG, array $context = [])
    {
        if($this->logger!=null)
        {
            $this->logger->log($level, $message, $context);
        }
    }
    
}
