<?php

/*
 * Copyright 2008-2016 Voiptech s.r.l.
 */

namespace CircleCRM\Cas\Security\Core\Role;

use DateTime;
use Serializable;
use Symfony\Component\Security\Core\Role\RoleInterface;
use JMS\Serializer\Annotation as JMS;

/**
 * VAuthEntity
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class VAuthEntity implements RoleInterface, Serializable
{

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\SerializedName("deleteRef")
     * @JMS\Type("string")
     */
    private $deleteRef;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $ref;

    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $created;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $delete;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $update;

    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $updated;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\SerializedName("createRef")
     * @JMS\Type("string")
     */
    private $createRef;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $view;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\SerializedName("assignRef")
     * @JMS\Type("string")
     */
    private $assignRef;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $create;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\SerializedName("updateRef")
     * @JMS\Type("string")
     */
    private $updateRef;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $name;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\SerializedName("viewRef")
     * @JMS\Type("string")
     */
    private $viewRef;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $assign;

    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $id;

    /**
     * 
     * @param string $name
     */
    public function __construct($name = null)
    {
        $this->name = $name;
    }

    /**
     * 
     * @return string
     */
    public function getDeleteRef()
    {
        return $this->deleteRef;
    }

    /**
     * 
     * @return string
     */
    public function getRef()
    {
        return $this->ref;
    }

    /**
     * 
     * @return DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * 
     * @return string
     */
    public function getDelete()
    {
        return $this->delete;
    }

    /**
     * 
     * @return string
     */
    public function getUpdate()
    {
        return $this->update;
    }

    /**
     * 
     * @return DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * 
     * @return string
     */
    public function getCreateRef()
    {
        return $this->createRef;
    }

    /**
     * 
     * @return string
     */
    public function getView()
    {
        return $this->view;
    }

    /**
     * 
     * @return string
     */
    public function getAssignRef()
    {
        return $this->assignRef;
    }

    /**
     * 
     * @return string
     */
    public function getCreate()
    {
        return $this->create;
    }

    /**
     * 
     * @return string
     */
    public function getUpdateRef()
    {
        return $this->updateRef;
    }

    /**
     * 
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 
     * @return string
     */
    public function getViewRef()
    {
        return $this->viewRef;
    }

    /**
     * 
     * @return string
     */
    public function getAssign()
    {
        return $this->assign;
    }

    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * 
     * @param string $deleteRef
     * @return VAuthEntity
     */
    public function setDeleteRef($deleteRef)
    {
        $this->deleteRef = $deleteRef;
        return $this;
    }

    /**
     * 
     * @param string $ref
     * @return VAuthEntity
     */
    public function setRef($ref)
    {
        $this->ref = $ref;
        return $this;
    }

    /**
     * 
     * @param DateTime $created
     * @return VAuthEntity
     */
    public function setCreated(DateTime $created)
    {
        $this->created = $created;
        return $this;
    }

    /**
     * 
     * @param string $delete
     * @return VAuthEntity
     */
    public function setDelete($delete)
    {
        $this->delete = $delete;
        return $this;
    }

    /**
     * 
     * @param string $update
     * @return VAuthEntity
     */
    public function setUpdate($update)
    {
        $this->update = $update;
        return $this;
    }

    /**
     * 
     * @param DateTime $updated
     * @return VAuthEntity
     */
    public function setUpdated(DateTime $updated)
    {
        $this->updated = $updated;
        return $this;
    }

    /**
     * 
     * @param string $createRef
     * @return VAuthEntity
     */
    public function setCreateRef($createRef)
    {
        $this->createRef = $createRef;
        return $this;
    }

    /**
     * 
     * @param string $view
     * @return VAuthEntity
     */
    public function setView($view)
    {
        $this->view = $view;
        return $this;
    }

    /**
     * 
     * @param string $assignRef
     * @return VAuthEntity
     */
    public function setAssignRef($assignRef)
    {
        $this->assignRef = $assignRef;
        return $this;
    }

    /**
     * 
     * @param string $create
     * @return VAuthEntity
     */
    public function setCreate($create)
    {
        $this->create = $create;
        return $this;
    }

    /**
     * 
     * @param string $updateRef
     * @return VAuthEntity
     */
    public function setUpdateRef($updateRef)
    {
        $this->updateRef = $updateRef;
        return $this;
    }

    /**
     * 
     * @param string $name
     * @return VAuthEntity
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * 
     * @param string $viewRef
     * @return VAuthEntity
     */
    public function setViewRef($viewRef)
    {
        $this->viewRef = $viewRef;
        return $this;
    }

    /**
     * 
     * @param string $assign
     * @return VAuthEntity
     */
    public function setAssign($assign)
    {
        $this->assign = $assign;
        return $this;
    }

    /**
     * 
     * @param string $id
     * @return VAuthEntity
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * 
     * @return string
     */
    public function getRole()
    {
        return $this->ref ? : $this->name;
    }

    /**
     * @return string $json
     */
    public function serialize()
    {
        return json_encode([
            $this->assign,
            $this->assignRef,
            $this->create,
            $this->createRef,
            $this->created == null ? : $this->created->format('Y-m-d\TH:i:s'),
            $this->delete,
            $this->deleteRef,
            $this->id,
            $this->name,
            $this->ref,
            $this->update,
            $this->updateRef,
            $this->updated == null ? : $this->updated->format('Y-m-d\TH:i:s'),
            $this->view,
            $this->viewRef
        ]);
    }

    /**
     * 
     * @param string $serialized json
     */
    public function unserialize($serialized)
    {
        $deserialized = json_decode($serialized);

        $this->assign = $deserialized[0];
        $this->assignRef = $deserialized[1];
        $this->create = $deserialized[2];
        $this->createRef = $deserialized[3];
        $this->created = $deserialized[4] == null ? : DateTime::createFromFormat('Y-m-d\TH:i:s', $deserialized[4]);
        $this->delete = $deserialized[5];
        $this->deleteRef = $deserialized[6];
        $this->id = $deserialized[7];
        $this->name = $deserialized[8];
        $this->ref = $deserialized[9];
        $this->update = $deserialized[10];
        $this->updateRef = $deserialized[11];
        $this->updated = $deserialized[12] == null ? : DateTime::createFromFormat('Y-m-d\TH:i:s', $deserialized[12]);
        $this->view = $deserialized[13];
        $this->viewRef = $deserialized[14];
    }

}
