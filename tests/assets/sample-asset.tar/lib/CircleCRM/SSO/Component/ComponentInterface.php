<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Component;

/**
 *
 * ComponentInterface Interface
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
interface ComponentInterface {
    
    /**
     * Return the Component ID
     * 
     * @return string the given component id
     */
    function getId();
    
    /**
     * Setup configuration.
     *
     * @param array $config
     */
    function setConfig(array $config);
    
    /**
     * 
     * @param string $name
     * @param mixed $value
     */
    function setConfigurationParam($name, $value);
    
    /**
     * 
     * Gets a configuration param by name
     * 
     * @param string $name
     * @return mixed|null
     */
    function getConfigurationParam($name, $default = null);
    
}
