<?php

/*
 * Copyright 2008-2014 Voiptech s.r.l.
 */

namespace CircleCRM\SSO\Security\Core\User;

use CircleCRM\SSO\Security\Core\Role\SsoRole;
use JMS\Serializer\Annotation as JMS;
use Symfony\Component\Security\Core\Role\RoleInterface;
use Symfony\Component\Security\Core\User\AdvancedUserInterface;

/**
 * SsoUser
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class SsoUser implements AdvancedUserInterface
{
    
    /**
     * @JMS\Expose
     * @JMS\XmlKeyValuePairs
     * 
     * @var array
     */
    private $attributes = [];
    
    /**
     * @JMS\Expose
     * @JMS\SerializedName("role")
     * @JMS\XmlList(inline=true, entry="role")
     * 
     * @var RoleInterface[]
     */
    private $roles = [];
    
    /**
     * @JMS\Expose
     * @JMS\Type("string")
     * 
     * @var string
     */
    private $username;
    
    public function __construct($username, array $attributes = [])
    {
        $this->username = $username;
        
        $this->attributes = $attributes;
        
        $roles = [];
        
        if(array_key_exists('role', $this->attributes))
        {
            $roles = is_array($this->attributes['role']) ? $this->attributes['role'] : [$this->attributes['role']];
            unset($this->attributes['role']);
        }
        
        foreach($roles as $role)
        {
            if(!($role instanceof RoleInterface))
            {
                $this->roles[] = new SsoRole($role);
            }else{
                $this->roles[] = $role;
            }
        }
    }
    
    public function eraseCredentials()
    {
        //do nothing
    }

    /**
     * 
     * @return null
     */
    public function getPassword()
    {
        return null;
    }

    /**
     * 
     * @return array
     */
    public function getRoles()
    {
        return $this->roles;
    }

    /**
     * 
     * @return null
     */
    public function getSalt()
    {
        return null;
    }

    /**
     * 
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }
    
    /**
     * 
     * @return array
     */
    public function getAttributes()
    {
        return $this->attributes;
    }
    
    public function isAccountNonExpired()
    {
        return $this->isEnabled();
    }

    public function isAccountNonLocked()
    {
        return $this->isEnabled();
    }

    public function isCredentialsNonExpired()
    {
        return $this->isEnabled();
    }

    public function isEnabled()
    {
        return $this->getIsEnabledFromAttributes();
    }
    
    /**
     * Lookups into attributes to find one telling if
     * this user is active or not. Default: isActive. 
     * Default if not found: true
     * 
     * @return bool
     */
    protected function getIsEnabledFromAttributes()
    {
        return (bool)$this->getFromAttributes('isActive', true);
    }
    
    /**
     * 
     * Extracts an attribute from attributes list
     * 
     * @param string $attributeName
     * @param mixed $default
     */
    protected function getFromAttributes($attributeName, $default = null)
    {
        if(array_key_exists($attributeName, $this->attributes))
        {
            return $this->attributes[$attributeName];
        }
        
        return $default;
    }
    
    
    
}
