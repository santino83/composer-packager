<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Protocol;

use CircleCRM\SSO\Component\AbstractComponent;
use CircleCRM\SSO\Protocol\ProtocolInterface;
use CircleCRM\SSO\Security\Core\Authentication\Token\SsoToken;
use CircleCRM\SSO\Serialization\SsoUserDeserializerInterface;
use CircleCRM\SSO\Serialization\SsoUserSerializerInterface;

/**
 * AbstractProtocol Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
abstract class AbstractProtocol extends AbstractComponent implements ProtocolInterface {

    /**
     *
     * @var SsoUserSerializerInterface
     */
    protected $userSerializer;
    
    /**
     *
     * @var SsoUserDeserializerInterface
     */
    protected $userDeserializer;
    
    public function processLogout(SsoToken $token)
    {
        // does nothing most of the case
    }
    
    public function getUserDeserializer()
    {
        return $this->userDeserializer;
    }

    public function getUserSerializer()
    {
        return $this->userSerializer;
    }

    /**
     * 
     * @param SsoUserSerializerInterface $userSerializer
     * @return $this
     */
    public function setUserSerializer(SsoUserSerializerInterface $userSerializer)
    {
        $this->userSerializer = $userSerializer;
        return $this;
    }

    /**
     * 
     * @param SsoUserDeserializerInterface $userDeserializer
     * @return $this
     */
    public function setUserDeserializer(SsoUserDeserializerInterface $userDeserializer)
    {
        $this->userDeserializer = $userDeserializer;
        return $this;
    }

}
