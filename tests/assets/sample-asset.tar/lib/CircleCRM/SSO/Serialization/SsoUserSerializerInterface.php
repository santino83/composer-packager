<?php
/*
 *  Voiptech s.r.l. 2017-2020
 */
namespace CircleCRM\SSO\Serialization;

use CircleCRM\SSO\Security\Core\User\SsoUser;

/**
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
interface SsoUserSerializerInterface
{
    
    /**
     * Serializes an user into a string
     * 
     * @param SsoUser $user the user
     * @return string the serialized user
     */
    function serialize(SsoUser $user);
    
    /**
     * Checks if this serializer supports the given user type
     * 
     * @param string $type the full classname
     * @return boolean true|false
     */
    function supports($type);
    
}
