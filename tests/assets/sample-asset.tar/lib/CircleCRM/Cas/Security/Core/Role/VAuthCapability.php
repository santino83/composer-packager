<?php

/*
 * Copyright 2008-2016 Voiptech s.r.l.
 */

namespace CircleCRM\Cas\Security\Core\Role;

use DateTime;
use Serializable;
use Symfony\Component\Security\Core\Role\RoleInterface;
use JMS\Serializer\Annotation as JMS;

/**
 * VAuthCapability
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class VAuthCapability implements RoleInterface, Serializable
{
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $created;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $id;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $ref;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $name;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $access;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\SerializedName("accessRef")
     * @JMS\Type("string")
     */
    private $accessRef;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $updated;
    
    /**
     * 
     * @param string $name
     */
    public function __construct($name = null)
    {
        $this->name = $name;
    }
    
    /**
     * 
     * @return DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * 
     * @return string
     */
    public function getRef()
    {
        return $this->ref;
    }

    /**
     * 
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 
     * @return string
     */
    public function getAccess()
    {
        return $this->access;
    }

    /**
     * 
     * @return string
     */
    public function getAccessRef()
    {
        return $this->accessRef;
    }

    /**
     * 
     * @return DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * 
     * @param DateTime $created
     * @return VAuthCapability
     */
    public function setCreated(DateTime $created)
    {
        $this->created = $created;
        return $this;
    }

    /**
     * 
     * @param string $id
     * @return VAuthCapability
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * 
     * @param string $ref
     * @return VAuthCapability
     */
    public function setRef($ref)
    {
        $this->ref = $ref;
        return $this;
    }

    /**
     * 
     * @param string $name
     * @return VAuthCapability
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * 
     * @param string $access
     * @return VAuthCapability
     */
    public function setAccess($access)
    {
        $this->access = $access;
        return $this;
    }

    /**
     * 
     * @param string $accessRef
     * @return VAuthCapability
     */
    public function setAccessRef($accessRef)
    {
        $this->accessRef = $accessRef;
        return $this;
    }

    /**
     * 
     * @param DateTime $updated
     * @return VAuthCapability
     */
    public function setUpdated(DateTime $updated)
    {
        $this->updated = $updated;
        return $this;
    }
    
    /**
     * 
     * @return string
     */
    public function getRole()
    {
        return $this->ref ?: $this->name;
    }

    /**
     * 
     * @return json
     */
    public function serialize()
    {
        return json_encode([
            $this->created == null ?: $this->created->format('Y-m-d\TH:i:s'),
            $this->id,
            $this->ref,
            $this->access,
            $this->accessRef,
            $this->name,
            $this->updated == null ?: $this->updated->format('Y-m-d\TH:i:s')
        ]);
    }

    /**
     * 
     * @param json $serialized
     */
    public function unserialize($serialized)
    {
        $deserialized = json_decode($serialized);
        $this->created = $deserialized[0] == null ?: DateTime::createFromFormat('Y-m-d\TH:i:s', $deserialized[0]);
        $this->id = $deserialized[1];
        $this->ref = $deserialized[2];
        $this->access = $deserialized[3];
        $this->accessRef = $deserialized[4];
        $this->name = $deserialized[5];
        $this->updated = $deserialized[6] == null ?: DateTime::createFromFormat('Y-m-d\TH:i:s', $deserialized[6]);
    }

}
