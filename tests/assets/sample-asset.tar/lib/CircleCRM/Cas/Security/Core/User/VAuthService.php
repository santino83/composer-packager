<?php

/*
 * Copyright 2008-2016 Voiptech s.r.l.
 */

namespace CircleCRM\Cas\Security\Core\User;

use DateTime;
use JMS\Serializer\Annotation as JMS;

/**
 * VAuthService
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class VAuthService
{
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $name;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $id;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $uri;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $tag;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $description;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $website;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $logo;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $created;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $updated;
    
    /**
     * 
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * 
     * @return string
     */
    public function getUri()
    {
        return $this->uri;
    }

    /**
     * 
     * @param string $name
     * @return VAuthService
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * 
     * @param string $id
     * @return VAuthService
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * 
     * @param string $uri
     * @return VAuthService
     */
    public function setUri($uri)
    {
        $this->uri = $uri;
        return $this;
    }
    
    /**
     * 
     * @return string
     */
    public function getTag()
    {
        return $this->tag;
    }

    /**
     * 
     * @param string $tag
     * @return VAuthService
     */
    public function setTag($tag)
    {
        $this->tag = $tag;
        return $this;
    }
    
    /**
     * 
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * 
     * @param string $description
     * @return $this
     */
    public function setDescription($description)
    {
        $this->description = $description;
        return $this;
    }
    
    /**
     * 
     * @return string
     */
    public function getWebsite()
    {
        return $this->website;
    }

    /**
     * 
     * @param string $website
     * @return $this
     */
    public function setWebsite($website)
    {
        $this->website = $website;
        return $this;
    }
    
    /**
     * 
     * @return string
     */
    public function getLogo()
    {
        return $this->logo;
    }

    /**
     * 
     * @param string $logo
     * @return $this
     */
    public function setLogo($logo)
    {
        $this->logo = $logo;
        return $this;
    }
    
    /**
     * 
     * @return DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * 
     * @return DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * 
     * @param DateTime $created
     * @return $this
     */
    public function setCreated(DateTime $created)
    {
        $this->created = $created;
        return $this;
    }

    /**
     * 
     * @param DateTime $updated
     * @return $this
     */
    public function setUpdated(DateTime $updated)
    {
        $this->updated = $updated;
        return $this;
    }
    
}
