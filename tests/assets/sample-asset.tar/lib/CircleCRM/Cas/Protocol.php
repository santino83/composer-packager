<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\Cas;

use CircleCRM\SSO\Protocol\AbstractProtocol;
use CircleCRM\SSO\Security\Core\User\SsoUser;
use CircleCRM\SSO\Server\ServerInterface;
use CircleCRM\SSO\Validation\ValidationInterface;
use GuzzleHttp\ClientInterface;
use InvalidArgumentException;
use Psr\Http\Message\ResponseInterface;
use Psr\Log\LogLevel;
use Symfony\Component\HttpFoundation\Request;

/**
 * Protocol Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class Protocol extends AbstractProtocol
{

    const CAS_1_0 = "CAS_1_0";
    const CAS_2_0 = "CAS_2_0";
    const CAS_3_0 = "CAS_3_0";
    const VAUTH_1_0 = "VAUTH_1_0";

    public static $DEFAULT = self::VAUTH_1_0;

    /**
     *
     * @var ValidationInterface[]
     */
    private $validationProviders = [];

    /**
     * 
     * @return string
     */
    public function getVersion()
    {
        return $this->getConfigurationParam("version", self::$DEFAULT);
    }

    /**
     * 
     * @param string $version
     */
    public function setVersion($version)
    {
        $this->setConfigurationParam("version", $version);
    }

    /**
     * 
     * @param ResponseInterface $response
     * @param mixed $credentials
     * @return ValidationInterface
     * @throws InvalidArgumentException
     */
    public function validateResponse(ResponseInterface $response, $credentials)
    {
        $this->log("Protocol::validateResponse() credentials => " . $credentials);

        $version = $this->getVersion();
        $this->log("Protocol::validateResponse() with version " . $version);

        $selectedProvider = null;
        /* @var $selectedProvider ValidationInterface */

        foreach ($this->validationProviders as $provider) {
            if ($provider->supports($version)) {
                $selectedProvider = $provider;
            }
        }

        if (null === $selectedProvider) {
            $this->log(sprintf("No Validation Provider for version %s ", $version), LogLevel::ERROR);
            throw new InvalidArgumentException(sprintf("No Validation Provider for version %s ", $version));
        }

        $selectedProvider->validate($response, $credentials);
        return $selectedProvider;
    }

    public function extractCredentials(Request $request)
    {
        return $request->query->get("ticket");
    }

    public function isValidationRequest(Request $request)
    {
        return $request->query->has("ticket");
    }

    public function extractUser(ValidationInterface $validation)
    {
        return $validation->getUser();
    }

    /**
     * 
     * @return ValidationInterface[]
     */
    public function getValidationProviders()
    {
        return $this->validationProviders;
    }

    /**
     * 
     * @param ValidationInterface[] $validationProviders
     */
    public function setValidationProviders(array $validationProviders = [])
    {
        $this->validationProviders = $validationProviders;
    }

    public function addValidationProvider(ValidationInterface $validationProvider)
    {
        $this->validationProviders[] = $validationProvider;
        return $this;
    }

    public function authenticate($username, $secret, ServerInterface $server, ClientInterface $client): SsoUser
    {
        $context = [
            'user' => null,
            'username' => $username,
            'secret' => $secret,
            'server' => $server,
            'client' => $client,
            'tgt' => null,
            'st' => null
        ];

        $this->getTGT($context)
                ->getST($context)
                ->validateST($context);

        return $context['user'];
    }

    private function getTGT(array &$context)
    {
        $body = ['username' => $context['username'], 'password' => $context['secret']];
        
        $client = $context['client'];
        /* @var $client ClientInterface */
        $response = $client->request('POST', $context['server']->getAuthenticationUrl(), ['form_params' => $body]);

        if ($response->getHeader('Location')) {
            $context['tgt'] = $response->getHeader('Location')[0];
        }

        return $this;
    }

    private function getST(array &$context)
    {
        if (!$context['tgt']) {
            return $this;
        }
        
        $body = ['service' => $context['server']->getServiceId()];
        
        $client = $context['client'];
        /* @var $client ClientInterface */
        $response = $client->request('POST', $context['tgt'],['form_params' => $body]);

        if ($response->getStatusCode() == 200) {
            $context['st'] = trim($response->getBody());
        }

        return $this;
    }

    private function validateST(array &$context)
    {
        if (!$context['st']) {
            return $this;
        }

        $request = $context['server']->getValidationHttpRequest($context['st']);
        $client = $context['client'];
        /* @var $client ClientInterface */
        $response = $client->send($request);
        $validation = $this->validateResponse($response, $context['st']);
        
        if($validation->isSuccess()){
            $context['user'] = $this->extractUser($validation);
        }
        
        return $this;
    }

}
