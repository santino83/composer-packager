<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Validation;

use CircleCRM\SSO\Security\Core\User\SsoUser;
use Psr\Http\Message\ResponseInterface;

/**
 *
 * ValidationInterface Interface
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
interface ValidationInterface {
    
    /**
     * Validates given response and credentials
     * 
     * @param ResponseInterface $response
     * @param mixed $credentials
     */
    function validate(ResponseInterface $response, $credentials);
    
    /**
     * Returns the SsoUser
     * 
     * @return SsoUser
     */
    function getUser();
    
    /**
     * Returns validation response.
     *
     * @deprecated since version 1.0
     * @return ResponseInterface
     */
    function getResponse();

    /**
     * Is validation successful?
     *
     * @return bool Validation success
     */
    function isSuccess();
    
    /**
     * Returns the validation status. see #ValidationStatus for valid status
     * 
     * @return int
     */
    function getStatus();

    /**
     * Returns SSO credentials (token).
     *
     * @deprecated since version 1.0
     * @return string A SSO token
     */
    function getCredentials();

    /**
     * Returns username if validation is successful.
     *
     * @return string The username
     */
    function getUsername();

    /**
     * Returns attributes given by SSO server.
     *
     * @return array An array of attributes
     */
    function getAttributes();

    /**
     * Returns an error message if validation was not successful.
     *
     * @return string An error message
     */
    function getError();
    
    /**
     * Checks if this Validation supports the given version
     * 
     * @param string $version
     * @return boolean true|false
     */
    function supports($version);
    
    /**
     * Returns the response, as string, returned from the server
     * 
     * @return string
     */
    function getSource();
    
}
