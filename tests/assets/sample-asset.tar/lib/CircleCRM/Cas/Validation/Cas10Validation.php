<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\Cas\Validation;

use CircleCRM\Cas\Protocol;
use CircleCRM\Cas\Validation\BaseValidation;
use CircleCRM\SSO\Validation\ValidationStatus;
use Psr\Log\LogLevel;

/**
 * Cas10Validation Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class Cas10Validation extends BaseValidation
{

    protected function validateResponse()
    {
        $body = $this->getSource();
        $this->log("Cas10Validation::validateResponse()");

        if (!$body) {
            $this->log("No content from response", LogLevel::ERROR);
            $this->setStatus(ValidationStatus::INVALID);
            return;
        }

        $this->log("Cas10Validation::validateResponse() contents => " . $body);

        $data = explode("\n", str_replace("\n\n", "\n", str_replace("\r", "\n", $body)));
        $success = strtolower($data[0]) === 'yes';
        $message = (count($data) > 1 && $data[1]) ? $data[1] : null;

        if ($success) {
            $this->setStatus(ValidationStatus::VALID);
            $this->setUsername($message);
        } else {
            $this->setStatus(ValidationStatus::INVALID);
            $this->setError($message);
        }
    }

    protected function getSupportedVersions()
    {
        return [Protocol::CAS_1_0];
    }

    protected function getBlacklistedAttributes()
    {
        return [];
    }

}
