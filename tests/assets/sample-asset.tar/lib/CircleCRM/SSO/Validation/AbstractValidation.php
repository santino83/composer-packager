<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Validation;

use CircleCRM\SSO\Security\Core\User\SsoUser;
use Psr\Http\Message\ResponseInterface;

/**
 * AbstractValidation Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
abstract class AbstractValidation implements ValidationInterface {
    
    /**
     *
     * @var int
     */
    protected $status;
    
    /**
     *
     * @var ResponseInterface
     */
    protected $response;
    
    /**
     *
     * @var mixed
     */
    protected $credentials;
    
    /**
     *
     * @var string
     */
    protected $username;
    
    /**
     *
     * @var array
     */
    protected $attributes;
    
    /**
     *
     * @var string
     */
    protected $error;
    
    /**
     *
     * @var string
     */
    protected $errorCode;
    
    /**
     *
     * @var string
     */
    protected $source;
    
    /**
     * 
     * @param ResponseInterface $response
     * @param mixed $credentials
     */
    public function __construct()
    {
        $this->reset();
    }
    
    public function validate(ResponseInterface $response, $credentials)
    {
        $this->reset();
        $this->response = $response;
        $this->credentials = $credentials;
        $this->validateResponse();
    }

    /**
     * 
     * @return array
     */
    public function getAttributes()
    {
        return $this->attributes;
    }

    /**
     * 
     * @return mixed
     */
    public function getCredentials()
    {
        return $this->credentials;
    }

    /**
     * 
     * @return string
     */
    public function getError()
    {
        return $this->error;
    }
    
    /**
     * 
     * @return string
     */
    public function getErrorCode()
    {
        return $this->errorCode;
    }

    /**
     * 
     * @return array
     */
    public function getPermissions()
    {
        return $this->permissions;
    }

    /**
     * 
     * @return ResponseInterface
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * 
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * 
     * @return boolean
     */
    public function isSuccess()
    {
        return $this->status === ValidationStatus::VALID;
    }
    
    /**
     * 
     * @return int
     */
    public function getStatus()
    {
        return $this->status;
    }
    
    public function supports($version)
    {
        $supportedVersions = $this->getSupportedVersions();
        if(!is_array($supportedVersions))
        {
            $supportedVersions = [$supportedVersions];
        }
        
        foreach($supportedVersions as $supportedVersion)
        {
            if(strtolower($version) == strtolower($supportedVersion))
            {
                return true;
            }
        }
        
        return false;
    }
    
    public function getUser()
    {
        return new SsoUser($this->getUsername(), $this->getAttributes());
    }
    
    public function getSource()
    {
        if(!$this->source && $this->response){
            $this->source = $this->response->getBody() instanceof \Psr\Http\Message\StreamInterface ?
                    $this->response->getBody()->getContents() : 
                    $this->response->getBody();
        }
        
        return $this->source;
    }
        
    /**
     * 
     * @param int $status
     * @return AbstractValidation
     */
    protected function setStatus($status)
    {
        $this->status = ValidationStatus::getValidStatus($status);
        return $this;
    }

    /**
     * 
     * @param string $username
     * @return AbstractValidation
     */
    protected function setUsername($username)
    {
        $this->username = $username;
        return $this;
    }

    /**
     * 
     * @param array $attributes
     * @return AbstractValidation
     */
    protected function setAttributes(array $attributes)
    {
        $this->attributes = $attributes;
        return $this;
    }
    
    /**
     * 
     * @param string $name
     * @param mixed $value
     * @return AbstractValidation
     */
    protected function appendAttribute($name, $value, $forceArray = false)
    {
        if(in_array($name, $this->getBlacklistedAttributes()))
        {
            // blacklisted attribute, skipping
            return $this;
        }
        
        if(array_key_exists($name, $this->attributes))
        {
            $this->attributes[$name] = is_array($this->attributes[$name]) ? 
            array_merge($this->attributes[$name],[$value]) : [$this->attributes[$name],$value];
        }else{
            $this->attributes[$name] = $forceArray ? [$value] : $value;            
        }
        
        return $this;
    }

    /**
     * 
     * @param string $error
     * @return AbstractValidation
     */
    protected function setError($error)
    {
        $this->error = $error;
        return $this;
    }
    
    /**
     * 
     * @param string $errorCode
     * @return AbstractValidation
     */
    protected function setErrorCode($errorCode)
    {
        $this->errorCode = $errorCode;
        return $this;
    }
    
    protected function reset()
    {
        $this->response = null;
        $this->credentials = null;
        $this->status = ValidationStatus::NONE;
        $this->username = null;
        $this->attributes = [];
        $this->error = null;
        $this->source = null;
    }
    
    /**
     * Fills up Validation from response. Override in subclasses
     * 
     * @return bool
     */
    abstract protected function validateResponse();
    
    /**
     * Returns the supported protocol versions for this validation
     * 
     * @return string[]
     */
    abstract protected function getSupportedVersions();
    
    /**
     * Returns an array of attribute names to be blacklisted
     * 
     * @return string[]
     */
    abstract protected function getBlacklistedAttributes();
    
}
