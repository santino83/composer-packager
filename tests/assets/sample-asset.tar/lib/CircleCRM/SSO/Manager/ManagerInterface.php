<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Manager;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use CircleCRM\SSO\Component\ComponentInterface;
use CircleCRM\SSO\Protocol\ProtocolInterface;
use CircleCRM\SSO\Security\Core\Authentication\Token\SsoToken;
use CircleCRM\SSO\Security\Core\User\SsoUser;
use CircleCRM\SSO\Server\ServerInterface;
use CircleCRM\SSO\Validation\ValidationInterface;

/**
 *
 * ManagerInterface Interface
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
interface ManagerInterface extends ComponentInterface {
    
    /**
     * Authenticates an user given his username and secret
     * 
     * @param string $username the username
     * @param string $secret the secret
     * @return SsoUser
     * @throws AuthenticationException
     */
    function authenticate($username, $secret);
    
    /**
     * Validates given credentials against SSO Server
     * 
     * @param mixed $credentials
     * @return ValidationInterface
     */
    function validateCredentials($credentials);
    
    /**
     * Creates an SSO Token
     * 
     * @param Request $request
     * @param String $providerKey
     * @return SsoToken
     */
    function createToken(Request $request, $providerKey);
    
    /**
     * Returns the server beeing used
     * 
     * @return ServerInterface the server
     */
    function getServer();
    
    /**
     * Returns The protocol beeing used
     * 
     * @return ProtocolInterface the protocol
     */
    function getProtocol();
    
    /**
     * Returns an SsoUser
     * 
     * @param ValidationInterface $validation
     * @return SsoUser
     * @throws AuthenticationException
     */
    function createUser(ValidationInterface $validation);
    
    /**
     * Serializes user into a json
     * 
     * @param SsoUser $user
     * @return string the serialized user
     */
    function serializeUser(SsoUser $user);
    
    /**
     * Deserialize json into a SsoUser
     * 
     * @param string $json
     * @return SsoUser the unserialized user
     */
    function deserializeUser($json);
    
}
