<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\Cas\Validation;

use CircleCRM\Cas\Protocol;
use CircleCRM\SSO\Validation\ValidationStatus;
use DOMDocument;
use DOMNode;
use Exception;
use Psr\Log\LogLevel;
use ReflectionClass;

/**
 * Cas20Validation Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class Cas20Validation extends BaseValidation
{

    /**
     *
     * @var ReflectionClass
     */
    protected $rclass;

    protected function validateResponse()
    {
        $content = $this->getSource();
        $this->log("Validating Response: " . $content);

        if (!$content) {
            $this->setStatus(ValidationStatus::INVALID);
            return;
        }

        $xml = new DOMDocument();

        try {
            if ($xml->loadXML($content)) {
                $this->handleXML($xml);
            } else {
                $this->log("Unable to parse response", LogLevel::ERROR);
                $this->setError("Unable to parse response");
                $this->setErrorCode(500);
            }
        } catch (Exception $ex) {
            $this->log("Unable to parse response: " . $ex->getMessage(), LogLevel::ERROR);
            $this->setStatus(ValidationStatus::INVALID);
            $this->setError($ex->getMessage());
            $this->setErrorCode($ex->getCode());
        }
    }

    protected function handleXML(DOMDocument $xml)
    {
        $this->rclass = new \ReflectionClass($this);
        $handled = false;
        foreach ($xml->firstChild->childNodes as $node) {
            /* @var $node DOMNode */
            if ($node->nodeName == "cas:authenticationSuccess") {
                $handled = true;
                $this->handleAuthenticationSuccess($node);
                break;
            } elseif ($node->nodeName == "cas:authenticationFailure") {
                $handled = true;
                $this->handleAuthenticationFailure($node);
                break;
            }
        }

        if (!$handled) {
            $this->log("Invalid protocol response", LogLevel::ERROR);
            $this->setStatus(ValidationStatus::INVALID);
            $this->setError("Invalid protocol response");
            $this->setErrorCode(501);
        }
    }

    protected function handleAuthenticationSuccess(DOMNode $root)
    {

        $this->setStatus(ValidationStatus::VALID);

        foreach ($root->childNodes as $child) {
            /* @var $child DOMNode */
            $this->handleNode($child);
        }
    }

    protected function handleAuthenticationFailure(DOMNode $root)
    {
        $this->setStatus(ValidationStatus::INVALID);
        $this->setError($this->cleanNodeValue($root->nodeValue));
        $this->setErrorCode($root->getAttribute("code"));
    }

    protected function handleNode(DOMNode $node)
    {
        $this->log("handling node: " . $node->nodeName);
        if ($node->nodeName == '#text') {
            return;
        }

        $methodName = str_replace(':', '', $node->nodeName) . 'Node';

        if ($this->rclass->hasMethod($methodName)) {
            $this->log("Using method " . $methodName . " for handling node");
            $method = $this->rclass->getMethod($methodName);
            $method->setAccessible(true);
            $method->invoke($this, $node);
        } else {
            $this->log("Unknown node, using default handler");
            $this->unknownNode($node);
        }
    }

    /**
     * Parses node <cas:user />
     * 
     * @param DOMNode $node
     */
    protected function casUserNode(DOMNode $node)
    {
        $this->setUsername($this->cleanNodeValue($node->textContent));
    }

    /**
     * Parses node <cas:attributes />
     * 
     * @param DOMNode $node
     */
    protected function casAttributesNode(DOMNode $node)
    {
        foreach ($node->childNodes as $child) {
            /* @var $child DOMNode */
            $this->handleNode($child);
        }
    }

    /**
     * Parses node <cas:attribute />
     * 
     * @param DOMNode $node
     */
    protected function casAttributeNode(DOMNode $node)
    {
        $this->appendAttribute($this->cleanNodeName($node->nodeName, 'cas:', ''), $this->cleanNodeValue($node->textContent));
    }

    /**
     * Parses unknown node name
     * 
     * @param DOMNode $node
     */
    protected function unknownNode(DOMNode $node)
    {
        $this->appendAttribute($this->cleanNodeName($node->nodeName, 'cas:', ''), $this->cleanNodeValue($node->textContent));
    }

    /**
     * Removes ns namespace from nodename, ie: cas:attributes => attributes
     * 
     * @param string $name
     * @param string $prefix
     * @param string $replace
     * @return string
     */
    protected function cleanNodeName($name, $prefix = 'cas:', $replace = '')
    {
        return str_replace($prefix, $replace, $name);
    }

    /**
     * Cleans the value. Now just using "trim" function is $value is a string
     * 
     * @param mixed $value
     * @return string|mixed
     */
    protected function cleanNodeValue($value)
    {
        if (is_string($value)) {
            return trim($value);
        }

        return $value;
    }

    protected function getSupportedVersions()
    {
        return [Protocol::CAS_2_0];
    }

    protected function getBlacklistedAttributes()
    {
        return [
          'isFromNewLogin', 'authenticationDate','successfulAuthenticationHandlers',
            'credentialType', 'authenticationMethod', 'longTermAuthenticationRequestTokenUsed'
        ];
    }

}
