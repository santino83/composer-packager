<?php

/*
 * Copyright 2008-2016 Voiptech s.r.l.
 */

namespace CircleCRM\Cas\Security\Core\User;

use DateTime;
use JMS\Serializer\Annotation as JMS;

/**
 * VAuthCompany
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class VAuthCompany
{
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $created;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $name;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $id;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $logo;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $vat;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $updated;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $favico;
    
    /**
     * 
     * @return DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * 
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * 
     * @return string
     */
    public function getLogo()
    {
        return $this->logo;
    }

    /**
     * 
     * @return string
     */
    public function getVat()
    {
        return $this->vat;
    }

    /**
     * 
     * @return DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * 
     * @return string
     */
    public function getFavico()
    {
        return $this->favico;
    }

    /**
     * 
     * @param DateTime $created
     * @return VAuthCompany
     */
    public function setCreated(DateTime $created)
    {
        $this->created = $created;
        return $this;
    }

    /**
     * 
     * @param string $name
     * @return VAuthCompany
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * 
     * @param string $id
     * @return VAuthCompany
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * 
     * @param string $logo
     * @return VAuthCompany
     */
    public function setLogo($logo)
    {
        $this->logo = $logo;
        return $this;
    }

    /**
     * 
     * @param string $vat
     * @return VAuthCompany
     */
    public function setVat($vat)
    {
        $this->vat = $vat;
        return $this;
    }

    /**
     * 
     * @param DateTime $updated
     * @return VAuthCompany
     */
    public function setUpdated(DateTime $updated)
    {
        $this->updated = $updated;
        return $this;
    }

    /**
     * 
     * @param string $favico
     * @return VAuthCompany
     */
    public function setFavico($favico)
    {
        $this->favico = $favico;
        return $this;
    }
    
}
