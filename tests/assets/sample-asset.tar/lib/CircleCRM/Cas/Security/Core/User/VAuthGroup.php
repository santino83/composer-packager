<?php

/*
 * Copyright 2008-2016 Voiptech s.r.l.
 */

namespace CircleCRM\Cas\Security\Core\User;

use DateTime;
use JMS\Serializer\Annotation as JMS;

/**
 * VAuthGroup
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class VAuthGroup
{
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $id;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $name;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $updated;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $created;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $ref;
    
    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * 
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 
     * @return DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * 
     * @return DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * 
     * @return string
     */
    public function getRef()
    {
        return $this->ref;
    }

    /**
     * 
     * @param string $id
     * @return VAuthGroup
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * 
     * @param string $name
     * @return VAuthGroup
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * 
     * @param DateTime $updated
     * @return VAuthGroup
     */
    public function setUpdated(DateTime $updated)
    {
        $this->updated = $updated;
        return $this;
    }

    /**
     * 
     * @param DateTime $created
     * @return VAuthGroup
     */
    public function setCreated(DateTime $created)
    {
        $this->created = $created;
        return $this;
    }

    /**
     * 
     * @param string $ref
     * @return VAuthGroup
     */
    public function setRef($ref)
    {
        $this->ref = $ref;
        return $this;
    }
    
}
