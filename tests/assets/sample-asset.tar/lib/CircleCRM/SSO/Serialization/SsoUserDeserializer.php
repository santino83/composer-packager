<?php

/*
 *  Voiptech s.r.l. 2017-2020
 */

namespace CircleCRM\SSO\Serialization;

use CircleCRM\SSO\Security\Core\Role\SsoRole;
use CircleCRM\SSO\Security\Core\User\SsoUser;
use Exception;
use JMS\Serializer\SerializerInterface;
use ReflectionClass;

/**
 * Description of SsoUserDeserializer
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class SsoUserDeserializer implements SsoUserDeserializerInterface
{
    
    /**
     *
     * @var SerializerInterface
     */
    protected $serializer;
    
    /**
     *
     * @var string
     */
    protected $format;
    
    /**
     * 
     * @param SerializerInterface $serializer
     * @param string $format
     */
    public function __construct(SerializerInterface $serializer, $format = 'json')
    {
        $this->serializer = $serializer;
        $this->format = $format;
    }
    
    public function deserialize($serialized)
    {
        $data = json_decode($serialized, true);
        
        $username = $data['username'];
        $roles = $data['role'];
        $attributes = $data['attributes'];
        
        return $this->createUser($username, $this->processRoles($roles ?: []), $this->processAttributes($attributes ?: []));
    }
    
    public function supports($type)
    {
        return $type == $this->getUserClass();
    }
    
    protected function createUser($username, array $roles = [], array $attributes = [])
    {
        if(!array_key_exists('role', $attributes))
        {
            $attributes['role'] = $roles;
        }
        
        $userClass = $this->getUserClass();
        return new $userClass($username, $attributes);
    }
    
    protected function processRoles(array $deserializedRoles = [])
    {
        $roles = [];
        foreach($deserializedRoles as $deserializedRole)
        {
            $roles[] = $this->processRole($deserializedRole);
        }
        
        return array_filter($roles);
    }
    
    protected function processAttributes(array $deserializedAttributes = [])
    {
        $rClass = new ReflectionClass($this);
        $attributes = [];
        
        foreach($deserializedAttributes as $key => $value)
        {
            $methodName = 'processAttribute'.$key;
            $processedValue = $value;
            
            if($rClass->hasMethod($methodName)){
                $method = $rClass->getMethod($methodName);
                $method->setAccessible(true);
                $processedValue = $method->invoke($this, $value);
            }
            
            $attributes[$key] = $processedValue;
        }
        
        return $attributes;
    }
    
    protected function processRole(array $deserializedRole = [])
    {
        return $this->deserializeObject($deserializedRole, $this->getRoleClass());
    }
    
    protected function getUserClass()
    {
        return SsoUser::class;
    }
    
    protected function getRoleClass()
    {
        return SsoRole::class;
    }

    /**
     * 
     * @param mixed $value
     * @param  $type
     * @return type
     */
    protected function deserializeObject($value, $type)
    {
        try{
            return $this->serializer->deserialize(json_encode($value), $type , $this->format);
        } catch (Exception $ex) {
            return null;
        }
    }
    
}
