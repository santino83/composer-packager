<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Server;

use Psr\Http\Message\RequestInterface;
use CircleCRM\SSO\Component\ComponentInterface;

/**
 *
 * ServerInterface Interface
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
interface ServerInterface extends ComponentInterface {
    
    /**
     * Returns the login url
     * 
     * @return string the login url
     */
    function getLoginUrl();
    
    /**
     * Returns the logout url
     * 
     * @return string the logout url
     */
    function getLogoutUrl();
    
    /**
     * Returns the url to be redirected on logout
     * 
     * @return string the redirect url
     */
    function getLogoutRedirect();
    
    /**
     * Returns the service id to be checked by the remote sso server
     * Could be a URL/ID/etc
     * 
     * @return string the service id
     */
    function getServiceId();
    
    /**
     * Returns the url for validate sso session
     * 
     * @return string the url
     */
    function getValidationUrl();
    
    /**
     * Build a validation request for given credentials
     * 
     * @param mixed $credentials
     * @return RequestInterface
     */
    function getValidationHttpRequest($credentials);
    
    /**
     * Returns the url for authentication request
     * 
     * @return string the url
     */
    function getAuthenticationUrl();
    
    /**
     * Build an authentication request for given credentials
     * 
     * @param string $username the username
     * @param string $secret the secret
     * @return RequestInterface
     */
    function getAuthenticationHttpRequest($username, $secret);
    
    /**
     * Returns the http method used for sending authentication request
     * 
     * @return string the http method
     */
    function getAuthenticationMethod();
    
    /**
     * Returns the ticket's url
     * 
     * @return string
     */
    function getTicketsUrl();
    
    /**
     * Returns the http method used for sending validation request
     * 
     * @return string the http method
     */
    function getValidationHttpMethod();
    
}
