<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Validation;

/**
 * ValidationStatus Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
abstract class ValidationStatus
{

    /**
     * Response not validated
     */
    const NONE = 0;

    /**
     * Validation successful
     */
    const VALID = 1;

    /**
     * Validation returns an error
     */
    const INVALID = -1;

    /**
     * Checkes if status is a valid one (NONE/VALID/INVALID). Returns INVALID otherwise
     * 
     * @param int $status
     * @return int
     */
    public static function getValidStatus($status)
    {
        if (in_array($status, [self::NONE, self::INVALID, self::VALID])) {
            return $status;
        }

        return self::INVALID;
    }

}
