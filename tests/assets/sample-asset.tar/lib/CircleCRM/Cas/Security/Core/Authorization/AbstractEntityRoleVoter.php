<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\Cas\Security\Core\Authorization;

use CircleCRM\Cas\Security\Core\Role\VAuthEntity;
use CircleCRM\Cas\Security\Core\User\VAuthUser;
use CircleCRM\SSO\Security\Core\Authorization\Voter\SsoVoter;
use CircleCRM\SSO\Security\Core\User\SsoUser;

/**
 * AbstractEntityRoleVoter Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
abstract class AbstractEntityRoleVoter extends SsoVoter {
    
    protected function supportsUser(SsoUser $user)
    {
        return $user instanceof VAuthUser;
    }
    
    protected function internalVote(SsoUser $user, $object, $attribute)
    {
        /*@var $user VAuthUser */
        foreach($user->getRoles() as $entityRole)
        {
            if($this->voteEntityRole($entityRole, $object, $attribute))
            {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Returns true/false if user has access to the object using the given entityRole/attribute pair
     * 
     * @param VAuthEntity $role
     * @param mixed $object
     * @param string $attribute
     * @return boolean
     */
    abstract protected function voteEntityRole(VAuthEntity $role, $object, $attribute);

}
