<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Security\Core\Authorization\Voter;

use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\VoterInterface;
use CircleCRM\SSO\Security\Core\User\SsoUser;

/**
 * SsoVoter Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
abstract class SsoVoter implements VoterInterface {
    
    const ACCESS = 'access';
    const VIEW = 'view';
    const CREATE = 'create';
    const EDIT = 'edit';
    const DELETE = 'delete';
    
    /**
     * 
     * @param string $attribute
     * @return boolean
     */
    public function supportsAttribute($attribute)
    {
        return in_array(strtolower($attribute), [
            self::ACCESS, self::VIEW, self::CREATE, self::EDIT, self::DELETE
        ]);
    }
    
    /**
     * 
     * @param string $class
     * @return boolean
     */
    public function supportsClass($class)
    {
        return true;
    }

    /**
     * 
     * @param TokenInterface $token
     * @param mixed $object
     * @param array $attributes
     * @return int @see VoterInterface constants
     */
    public function vote(TokenInterface $token, $object, array $attributes = [])
    {
        if( null !== $object && is_object($object) && !$this->supportsClass(get_class($object)))
        {
            return VoterInterface::ACCESS_ABSTAIN;
        }
        
        $supportAttributes = true;  
        foreach($attributes as $attribute)
        {
            $supportAttributes = $supportAttributes && $this->supportsAttribute($attribute);
        }
        
        //must supports all passed attributes
        if(!$supportAttributes)
        {
            return VoterInterface::ACCESS_ABSTAIN;
        }
        
        //get logged user
        $user = $token->getUser();
        
        //only ssoUsers could have access by this voter
        if(!($user instanceof SsoUser) || !$this->supportsUser($user))
        {
            return VoterInterface::ACCESS_DENIED;
        }
        
        foreach($attributes as $attribute)
        {
            if($this->internalVote($user, $object, $attribute))
            {
                return VoterInterface::ACCESS_GRANTED;
            }
        }
        
        return VoterInterface::ACCESS_DENIED;
    }
    
    /**
     * Check if the voter supports the SsoUser
     * 
     * @param SsoUser $user
     * @return boolean
     */
    protected function supportsUser(SsoUser $user)
    {
        return true;
    }
    
    /**
     * Return true or false if user has granting access to the object by the given attribute
     * 
     * @param SsoUser $user
     * @param mixed $object
     * @param string $attribute
     * @return boolean
     */
    abstract protected function internalVote(SsoUser $user, $object, $attribute);

}
