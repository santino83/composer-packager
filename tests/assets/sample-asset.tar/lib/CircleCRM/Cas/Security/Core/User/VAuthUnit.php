<?php

/*
 * Copyright 2008-2016 Voiptech s.r.l.
 */

namespace CircleCRM\Cas\Security\Core\User;

use DateTime;
use JMS\Serializer\Annotation as JMS;

/**
 * VAuthUnit
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class VAuthUnit
{
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $email;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $updated;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $name;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $created;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $ref;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $website;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $fax;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $phone;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $id;
    
    /**
     * 
     * @param string $email
     * @return VAuthUnit
     */
    public function setEmail($email)
    {
        $this->email = $email;
        return $this;
    }

    /**
     * 
     * @param DateTime $updated
     * @return VAuthUnit
     */
    public function setUpdated(DateTime $updated)
    {
        $this->updated = $updated;
        return $this;
    }

    /**
     * 
     * @param string $name
     * @return VAuthUnit
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * 
     * @param DateTime $created
     * @return VAuthUnit
     */
    public function setCreated(DateTime $created)
    {
        $this->created = $created;
        return $this;
    }

    /**
     * 
     * @param string $ref
     * @return VAuthUnit
     */
    public function setRef($ref)
    {
        $this->ref = $ref;
        return $this;
    }

    /**
     * 
     * @param string $website
     * @return VAuthUnit
     */
    public function setWebsite($website)
    {
        $this->website = $website;
        return $this;
    }

    /**
     * 
     * @param string $fax
     * @return VAuthUnit
     */
    public function setFax($fax)
    {
        $this->fax = $fax;
        return $this;
    }

    
    /**
     * 
     * @param string $phone
     * @return VAuthUnit
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
        return $this;
    }

    /**
     * 
     * @param string $id
     * @return VAuthUnit
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }
    
    /**
     * 
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * 
     * @return DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * 
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 
     * @return DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * 
     * @return string
     */
    public function getRef()
    {
        return $this->ref;
    }

    /**
     * 
     * @return string
     */
    public function getWebsite()
    {
        return $this->website;
    }

    /**
     * 
     * @return string
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * 
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }
    
}
