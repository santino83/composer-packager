<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Server;

use CircleCRM\SSO\Component\AbstractComponent;

/**
 * AbstractServer Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
abstract class AbstractServer extends AbstractComponent implements ServerInterface {
    
    const GET_METHOD = "GET";
    const POST_METHOD = "POST";
    
    public static $DEFAULT_HTTP_METHOD = self::GET_METHOD;
    
    /**
     * 
     * @return string
     */
    public function getLoginUrl()
    {
        return $this->getConfigurationParam("login_url");
    }

    /**
     * 
     * @return string
     */
    public function getLogoutRedirect()
    {
        return $this->getConfigurationParam("logout_redirect");
    }

    /**
     * 
     * @return string
     */
    public function getLogoutUrl()
    {
        return $this->getConfigurationParam("logout_url");
    }

    /**
     * 
     * @return string
     */
    public function getServiceId()
    {
         return $this->getConfigurationParam("service_id");
    }
    
    /**
     * 
     * @return string
     */
    public function getValidationUrl()
    {
        return $this->getConfigurationParam("validation_url");
    }
    
    /**
     * 
     * @return string
     */
    public function getTicketsUrl()
    {
        return $this->getConfigurationParam("tickets_url");
    }

    /**
     * Returns the http method used for sending validation request
     * 
     * @return string the http method
     */
    public function getValidationHttpMethod()
    {
        return $this->getConfigurationParam("validation_method",self::$DEFAULT_HTTP_METHOD);
    }
    
    /**
     * 
     * @param string $method an HTTP method
     */
    public function setValidationHttpMethod($method)
    {
        $this->setConfigurationParam("validation_method", $method);
    }
    
    public function getAuthenticationMethod()
    {
        return $this->getConfigurationParam("authentication_method", self::POST_METHOD);
    }

    public function getAuthenticationUrl()
    {
        return $this->getConfigurationParam("authentication_url");
    }

}
