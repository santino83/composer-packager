<?php
/*
 * Property of Voiptech s.r.l. 
 */
namespace CircleCRM\SSO\Protocol;

use CircleCRM\SSO\Component\ComponentInterface;
use CircleCRM\SSO\Security\Core\Authentication\Token\SsoToken;
use CircleCRM\SSO\Security\Core\User\SsoUser;
use CircleCRM\SSO\Serialization\SsoUserDeserializerInterface;
use CircleCRM\SSO\Serialization\SsoUserSerializerInterface;
use CircleCRM\SSO\Server\ServerInterface;
use CircleCRM\SSO\Validation\ValidationInterface;
use GuzzleHttp\ClientInterface;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\HttpFoundation\Request as SymfonyRequest;

/**
 *
 * ProtocolInterface Interface
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
interface ProtocolInterface extends ComponentInterface {
    
    /**
     * Performs logout operation
     * 
     * @param SsoToken $token
     * @return void
     */
    function processLogout(SsoToken $token);
    
    /**
     * Checks if sso is beeing validated
     * 
     * @param SymfonyRequest $request
     * @return boolean
     */
    function isValidationRequest(SymfonyRequest $request);
    
    /**
     * Gets credentials from request (ie: the sso ticket)
     * 
     * @param SymfonyRequest $request
     * @return mixed credentials
     */
    function extractCredentials(SymfonyRequest $request);
    
    /**
     * Validate the Response from SsoServer
     * 
     * @param ResponseInterface $response
     * @param mixed $credentials
     * @return ValidationInterface validation
     */
    function validateResponse(ResponseInterface $response, $credentials);
 
    /**
     * Extract the SsoUser from validation information
     * 
     * @deprecated since version 1.0. Move login into validation
     * @param ValidationInterface $validation
     * @return SsoUser
     */
    function extractUser(ValidationInterface $validation);
    
    /**
     * Sets a list of validation providers to validate the protocol response
     * 
     * @param ValidationInterface[] $validationProviders
     */
    function setValidationProviders(array $validationProviders = []);
    
    /**
     * Adds a validation provider to the list of validation providers
     * 
     * @param ValidationInterface $validationProvider
     */
    function addValidationProvider(ValidationInterface $validationProvider);
    
    /**
     * TODO: refactory!
     * 
     * @param string $username
     * @param string $secret
     * @param ServerInterface $server
     * @param ClientInterface $client
     * @return SsoUser
     */
    function authenticate($username, $secret, ServerInterface $server, ClientInterface $client );
    
    /**
     * @return SsoUserSerializerInterface
     */
    function getUserSerializer();
    
    /**
     * @return SsoUserDeserializerInterface
     */
    function getUserDeserializer();
    
}
