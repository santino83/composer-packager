<?php

/*
 *  Voiptech s.r.l. 2017-2020
 */

namespace CircleCRM\SSO\Serialization;

use CircleCRM\SSO\Security\Core\User\SsoUser;

/**
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
interface SsoUserDeserializerInterface
{
    
    /**
     * Deserializes a string into an SsoUser
     * 
     * @param string $serialized the serialized user
     * @return SsoUser
     */
    function deserialize($serialized);
    
    /**
     * Checks if this serializer supports the given user type
     * 
     * @param string $type the full classname
     * @return boolean true|false
     */
    function supports($type);
    
}
