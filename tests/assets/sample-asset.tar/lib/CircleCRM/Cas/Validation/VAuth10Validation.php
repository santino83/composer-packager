<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\Cas\Validation;

use CircleCRM\Cas\Protocol;
use CircleCRM\Cas\Security\Core\Role\VAuthCapability;
use CircleCRM\Cas\Security\Core\Role\VAuthEntity;
use CircleCRM\Cas\Security\Core\Role\VAuthRole;
use CircleCRM\Cas\Security\Core\User\VAuthCompany;
use CircleCRM\Cas\Security\Core\User\VAuthGroup;
use CircleCRM\Cas\Security\Core\User\VAuthService;
use CircleCRM\Cas\Security\Core\User\VAuthUnit;
use CircleCRM\Cas\Security\Core\User\VAuthUser;
use DateTime;
use DOMNode;
use JMS\Serializer\SerializerBuilder;
use JMS\Serializer\SerializerInterface;

/**
 * VAuth10Validation Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class VAuth10Validation extends Cas30Validation
{
    
    /**
     *
     * @var SerializerInterface
     */
    private $serializer;
    
    public function getUser()
    {
        return new VAuthUser($this->getUsername(), $this->getAttributes());
    }
    
    /**
     * It's needed beacuse when SSO with Google, username is not the user's email
     * but it's the java pac4j id
     * 
     * @return string
     */
    public function getUsername()
    {
        return $this->getAttributes() && array_key_exists('email', $this->getAttributes()) ?
                $this->getAttributes()['email'] :
                parent::getUsername();
    }
    
    /**
     * 
     * @param SerializerInterface $serializer
     * @return $this
     */
    public function setSerializer(SerializerInterface $serializer = null)
    {
        $this->serializer = $serializer;
        return $this;
    }
        /**
     * 
     * Parses node
     * <code>
     *   <cas:role>html_entitites_encoded(json_serialized(VAuthRole))</cas:role>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casRoleNode(DOMNode $node)
    {
        $role = $this->deserialize($node, VAuthRole::class);
        $this->appendAttribute("role", $role, true);
    }

    /**
     * 
     * Parses node
     * <code>
     *  <cas:unit>html_entitites_encoded(json_serialized(VAuthUnit))</cas:unit>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casUnitNode(DOMNode $node)
    {
        $unit = $this->deserialize($node, VAuthUnit::class);
        $this->appendAttribute("unit", $unit);
    }

    /**
     * 
     * Parses node
     * <code>
     *  <cas:capability>html_entitites_encoded(json_serialized(VAuthCapability))</cas:capability>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casCapabilityNode(DOMNode $node)
    {
        $capability = $this->deserialize($node, VAuthCapability::class);
        $this->appendAttribute("capability", $capability, true);
    }

    /**
     * 
     * Parses node
     * <code>
     *  <cas:service>html_entitites_encoded(json_serialized(VAuthService))</cas:service>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casServiceNode(DOMNode $node)
    {
        $service = $this->deserialize($node, VAuthService::class);
        $this->appendAttribute("service", $service, true);
    }

    /**
     * 
     * Parses node
     * <code>
     *  <cas:company>html_entitites_encoded(json_serialized(VAuthCompany))</cas:company>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casCompanyNode(DOMNode $node)
    {
        $company = $this->deserialize($node, VAuthCompany::class);
        $this->appendAttribute("company", $company);
    }

    /**
     * 
     * Parses node
     * <code>
     *  <cas:entity>html_entitites_encoded(json_serialized(VAuthEntity))</cas:entity>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casEntityNode(DOMNode $node)
    {
        $entity = $this->deserialize($node, VAuthEntity::class);
        $this->appendAttribute('entity', $entity, true);
    }

    /**
     * 
     * Parses node
     * <code>
     *  <cas:group>html_entitites_encoded(json_serialized(VAuthGroup))</cas:group>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casGroupNode(DOMNode $node)
    {
        $group = $this->deserialize($node, VAuthGroup::class);
        $this->appendAttribute("group", $group, true);
    }

    /**
     * Parses nodes
     * <code>
     *  <cas:created>datetime</cas:created>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casCreatedNode(DOMNode $node)
    {
        $value = $this->cleanNodeValue($node->nodeValue);
        $this->appendAttribute('created', DateTime::createFromFormat('Y-m-d\TH:i:sP', $value));
    }
    
    /**
     * Parses nodes
     * <code>
     *  <cas:updated>datetime</cas:updated>
     * </code>
     * 
     * @param DOMNode $node
     */
    protected function casUpdatedNode(DOMNode $node)
    {
        $value = $this->cleanNodeValue($node->nodeValue);
        $this->appendAttribute('updated', DateTime::createFromFormat('Y-m-d\TH:i:sP', $value));
    }
    
    /**
     * Deserialize the given node into the givenm type
     * 
     * @param DOMNode $node the node holding the encoded json
     * @param string $type the classname
     * @param string $format default 'json'
     * @return mixed the deserialized object
     */
    private function deserialize(DOMNode $node, $type, $format = 'json')
    {
        if(null === $this->serializer)
        {
            $this->serializer = SerializerBuilder::create()->build();
        }
        
        $value = $node->nodeValue;
        $json = html_entity_decode($value);
        return $this->serializer->deserialize($json, $type, $format);
    }
    
    protected function getSupportedVersions()
    {
        $parentVersions = parent::getSupportedVersions();
        $parentVersions[] = Protocol::VAUTH_1_0;
        
        return $parentVersions;
    }

}
