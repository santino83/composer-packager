<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\Cas\Security\Core\User;

use DateTime;
use CircleCRM\Cas\Security\Core\Role\VAuthCapability;
use CircleCRM\Cas\Security\Core\Role\VAuthEntity;
use CircleCRM\SSO\Security\Core\User\SsoUser;

/**
 * VAuthUser Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class VAuthUser extends SsoUser
{

    /**
     * 
     * @return string
     */
    public function getUsername()
    {
        return $this->getEmail();
    }

    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->getFromAttributes("id");
    }

    /**
     * 
     * @return string
     */
    public function getFirstanme()
    {
        return $this->getFromAttributes("firstname");
    }

    /**
     * 
     * @return string
     */
    public function getLastname()
    {
        return $this->getFromAttributes("lastname");
    }

    /**
     * 
     * @return string
     */
    public function getToken()
    {
        return $this->getFromAttributes("token");
    }

    /**
     * 
     * @return string
     */
    public function getEmail()
    {
        return $this->getFromAttributes("email");
    }

    /**
     * 
     * @return VAuthCompany
     */
    public function getCompany()
    {
        return $this->getFromAttributes("company");
    }

    /**
     * 
     * @return VAuthUnit
     */
    public function getUnit()
    {
        return $this->getFromAttributes("unit");
    }

    /**
     * 
     * @return string
     */
    public function getOAuthProvider()
    {
        return $this->getFromAttributes("oauth_provider");
    }

    /**
     * 
     * @return string
     */
    public function getOAuthId()
    {
        return $this->getFromAttributes("oauth_id");
    }

    /**
     * 
     * @return VAuthGroup[]
     */
    public function getGroups()
    {
        $groups = $this->getFromAttributes("group");

        return is_array($groups) ? $groups : [$groups];
    }

    /**
     * 
     * @return VAuthService[]
     */
    public function getServices()
    {
        $services = $this->getFromAttributes("service");

        return is_array($services) ? $services : [$services];
    }

    /**
     * 
     * @return VAuthCapability[]
     */
    public function getCapabilities()
    {
        $capabilities = $this->getFromAttributes("capability");
        return is_array($capabilities) ? $capabilities : [$capabilities];
    }

    /**
     * 
     * @return VAuthEntity[]
     */
    public function getEntities()
    {
        $entities = $this->getFromAttributes("entity");
        return is_array($entities) ? $entities : [$entities];
    }

    /**
     * 
     * @return DateTime
     */
    public function getCreated()
    {
        return $this->getFromAttributes("created");
    }

    /**
     * 
     * @return DateTime
     */
    public function getUpdated()
    {
        return $this->getFromAttributes("updated");
    }

    /**
     * 
     * @return boolean
     */
    public function getIsActive()
    {
        return $this->getIsEnabledFromAttributes();
    }

}
