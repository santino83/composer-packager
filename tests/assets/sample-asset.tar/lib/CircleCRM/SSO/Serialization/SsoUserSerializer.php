<?php

/*
 *  Voiptech s.r.l. 2017-2020
 */

namespace CircleCRM\SSO\Serialization;

use CircleCRM\SSO\Security\Core\User\SsoUser;
use JMS\Serializer\SerializerInterface;

/**
 * Description of SsoUserSerializer
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class SsoUserSerializer implements SsoUserSerializerInterface
{

    /**
     *
     * @var SerializerInterface
     */
    protected $serializer;
    
    /**
     *
     * @var string
     */
    protected $format;

    /**
     * 
     * @param SerializerInterface $serializer
     * @param string $format
     */
    public function __construct(SerializerInterface $serializer, $format = 'json')
    {
        $this->serializer = $serializer;
        $this->format = $format;
    }

    public function serialize(SsoUser $user)
    {
        return $this->serializer->serialize($user, $this->format);
    }
    
    public function supports($type)
    {
        return true;
    }

}
