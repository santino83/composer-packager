<?php

/*
 *  Voiptech s.r.l. 2017-2020
 */

namespace CircleCRM\Cas\Serialization;

use CircleCRM\Cas\Security\Core\Role\VAuthCapability;
use CircleCRM\Cas\Security\Core\Role\VAuthEntity;
use CircleCRM\Cas\Security\Core\Role\VAuthRole;
use CircleCRM\Cas\Security\Core\User\VAuthCompany;
use CircleCRM\Cas\Security\Core\User\VAuthGroup;
use CircleCRM\Cas\Security\Core\User\VAuthService;
use CircleCRM\Cas\Security\Core\User\VAuthUnit;
use CircleCRM\Cas\Security\Core\User\VAuthUser;
use CircleCRM\SSO\Serialization\SsoUserDeserializer;
use DateTime;

/**
 * Description of VAuthUserDeserializer
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class VAuthUserDeserializer extends SsoUserDeserializer
{
 
    /**
     * 
     * @param string $value
     * @return DateTime
     */
    protected function processAttributeCreated($value)
    {
        return $this->deserializeObject($value, DateTime::class);
    }
    
    /**
     * 
     * @param string $value
     * @return boolean
     */
    protected function processAttributeIsActive($value)
    {
        return $value ? (bool)$value : false;
    }
    
    /**
     * 
     * @param array $value
     * @return VAuthUnit
     */
    protected function processAttributeUnit($value)
    {
        return $this->deserializeObject($value, VAuthUnit::class);
    }
    
    /**
     * 
     * @param array $value
     * @return VAuthCapability[]
     */
    protected function processAttributeCapability($value)
    {
        return $this->deserializeObjectArray($value, VAuthCapability::class);
    }
    
    /**
     * 
     * @param array $value
     * @return VAuthService[]
     */
    protected function processAttributeService($value)
    {
        return $this->deserializeObjectArray($value, VAuthService::class);
    }
    
    /**
     * 
     * @param array $value
     * @return VAuthCompany
     */
    protected function processAttributeCompany($value)
    {
        return $this->deserializeObject($value, VAuthCompany::class);
    }
    
    /**
     * 
     * @param string $value
     * @return boolean
     */
    protected function processAttributeUpdated($value)
    {
        return $this->deserializeObject($value, DateTime::class);
    }
    
    /**
     * 
     * @param array $value
     * @return VAuthEntity[]
     */
    protected function processAttributeEntity($value)
    {
        return $this->deserializeObjectArray($value, VAuthEntity::class);
    }
    
    /**
     * 
     * @param array $value
     * @return VAuthGroup[]
     */
    protected function processAttributeGroup($value)
    {
        return $this->deserializeObjectArray($value, VAuthGroup::class);
    }
    
    protected function getRoleClass()
    {
        return VAuthRole::class;
    }

    protected function getUserClass()
    {
        return VAuthUser::class;
    }

    /**
     * 
     * @param mixed $value
     * @param string $type
     * @return mixed
     */
    private function deserializeObjectArray($value, $type)
    {
        if(!is_array($value))
        {
            $value = [$value];
        }
        
        $values = [];
        foreach($value as $v)
        {
            $values[] = $this->deserializeObject($v, $type);
        }
        
        return array_filter($values);
    }
    
}
