<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\SSO\Security\Core\Authentication\Token;

use InvalidArgumentException;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Role\Role;
use Symfony\Component\Security\Core\Role\RoleInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use CircleCRM\SSO\Security\Core\User\SsoUser;

/**
 * SsoToken Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class SsoToken implements TokenInterface{
    
    private $ticket;
    
    private $providerKey;
    
    private $user;
    
    private $roles = [];
    
    private $authenticated = false;
    
    private $attributes = [];
    
    /**
     * 
     * @param string $ticket
     * @param string $providerKey
     * @param SsoUser $user
     * @param boolean $authenticated
     * @param array $roles
     */
    public function __construct($ticket, $providerKey = null, SsoUser $user = null, $authenticated = false, array $roles = [])
    {
        foreach ($roles as $role) {
            if (is_string($role)) {
                $role = new Role($role);
            } elseif (!$role instanceof RoleInterface) {
                throw new InvalidArgumentException(sprintf('$roles must be an array of strings, or RoleInterface instances, but got %s.', gettype($role)));
            }

            $this->roles[] = $role;
        }
        
        $this->authenticated = $authenticated;
        
        if($user!=null)
        {
            $this->setUser($user);
            $this->attributes = $user->getAttributes();
            $this->roles = array_merge($this->roles, $user->getRoles());
        }
        
        $this->ticket = $ticket;
        $this->providerKey = $providerKey;
    }    

    public function eraseCredentials()
    {
        if ($this->getUser() instanceof UserInterface) {
            $this->getUser()->eraseCredentials();
        }
    }

    public function getAttribute($name)
    {
        if (!array_key_exists($name, $this->attributes)) {
            throw new InvalidArgumentException(sprintf('This token has no "%s" attribute.', $name));
        }

        return $this->attributes[$name];
    }

    public function getAttributes()
    {
        return $this->attributes;
    }

    public function getProviderKey()
    {
        return $this->providerKey;
    }
    
    public function getCredentials()
    {
        return $this->ticket;
    }

    public function getRoles()
    {
        return $this->roles;
    }

    public function getUser()
    {
        return $this->user;
    }

    public function getUsername()
    {
        if ($this->user instanceof UserInterface) {
            return $this->user->getUsername();
        }

        return (string) $this->user;
    }

    public function hasAttribute($name)
    {
        return array_key_exists($name, $this->attributes);
    }

    public function isAuthenticated()
    {
        return $this->authenticated;
    }

    public function serialize()
    {
        return serialize(
            array(
                $this->ticket,
                $this->providerKey,
                is_object($this->user) ? clone $this->user : $this->user,
                $this->authenticated,
                $this->roles,
                $this->attributes,
            )
        );
    }

    public function setAttribute($name, $value)
    {
        $this->attributes[$name] = $value;
    }

    public function setAttributes(array $attributes)
    {
        $this->attributes = $attributes;
    }

    public function setAuthenticated($isAuthenticated)
    {
        $this->authenticated = (bool) $authenticated;
    }

    public function setUser($user)
    {
        if (!($user instanceof UserInterface || (is_object($user) && method_exists($user, '__toString')) || is_string($user))) {
            throw new InvalidArgumentException('$user must be an instanceof UserInterface, an object implementing a __toString method, or a primitive string.');
        }

        $this->user = $user;
    }

    public function unserialize($serialized)
    {
        list($this->ticket, $this->providerKey, $this->user, $this->authenticated, $this->roles, $this->attributes) = unserialize($serialized);
    }

    public function __toString()
    {
        $class = get_class($this);
        $class = substr($class, strrpos($class, '\\')+1);

        $roles = array();
        foreach ($this->roles as $role) {
            $roles[] = $role->getRole();
        }

        return sprintf('%s(user="%s", authenticated=%s, roles="%s", token="%s")', $class, $this->getUsername(), json_encode($this->authenticated), implode(', ', $roles), $this->ticket);
    }
    
}

