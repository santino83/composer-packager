<?php

/*
 *  Voiptech s.r.l. 2017-2020
 */

namespace CircleCRM\SSO\Security\Core\Role;

use JMS\Serializer\Annotation as JMS;
use Symfony\Component\Security\Core\Role\RoleInterface;

/**
 * Description of SsoRole
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class SsoRole implements RoleInterface
{
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $role;
    
    public function __construct($role)
    {
        $this->role = (string)$role;
    }

    public function getRole()
    {
        return $this->role;
    }

}
