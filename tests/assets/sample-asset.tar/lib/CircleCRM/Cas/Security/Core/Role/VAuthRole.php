<?php

/*
 * Copyright 2008-2016 Voiptech s.r.l.
 */

namespace CircleCRM\Cas\Security\Core\Role;

use DateTime;
use JMS\Serializer\Annotation as JMS;
use Symfony\Component\Security\Core\Role\RoleInterface;

/**
 * VAuthRole
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 * @JMS\ExclusionPolicy("ALL")
 */
class VAuthRole implements RoleInterface
{
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $name;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $id;
    
    /**
     *
     * @var string
     * 
     * @JMS\Expose
     * @JMS\Type("string")
     */
    private $ref;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $created;
    
    /**
     *
     * @var DateTime
     * 
     * @JMS\Expose
     * @JMS\Type("DateTime<'Y-m-d\TH:i:sP'>")
     */
    private $updated;
    
    /**
     * 
     * @param string $role
     */
    public function __construct($role = null)
    {
        $this->name = $role;
    }

    /**
     * 
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * 
     * @return string
     */
    public function getRef()
    {
        return $this->ref;
    }

    /**
     * 
     * @return DateTime
     */
    public function getCreated()
    {
        return $this->created;
    }

    /**
     * 
     * @return DateTime
     */
    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * 
     * @param string $name
     * @return VAuthRole
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * 
     * @param string $id
     * @return VAuthRole
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }

    /**
     * 
     * @param string $ref
     * @return VAuthRole
     */
    public function setRef($ref)
    {
        $this->ref = $ref;
        return $this;
    }

    /**
     * 
     * @param DateTime $created
     * @return VAuthRole
     */
    public function setCreated(DateTime $created)
    {
        $this->created = $created;
        return $this;
    }

    /**
     * 
     * @param DateTime $updated
     * @return VAuthRole
     */
    public function setUpdated(DateTime $updated)
    {
        $this->updated = $updated;
        return $this;
    }
    
    /**
     * 
     * @return string
     */
    public function getRole()
    {
        return $this->ref ?: $this->name;
    }

}
