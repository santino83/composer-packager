<?php

/*
 * Property of Voiptech s.r.l. 
 */

namespace CircleCRM\Cas\Validation;

use CircleCRM\Cas\Protocol;

/**
 * Cas30Validation Class
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class Cas30Validation extends Cas20Validation {
    
    
    protected function getSupportedVersions()
    {
        $parentVersions = parent::getSupportedVersions();
        $parentVersions[] = Protocol::CAS_3_0;
        
        return $parentVersions;
    }
    
}
