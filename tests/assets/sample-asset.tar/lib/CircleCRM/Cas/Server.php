<?php

/*
 * Copyright 2008-2014 Voiptech s.r.l.
 */

namespace CircleCRM\Cas;

use GuzzleHttp\Psr7\Request;
use Psr\Http\Message\RequestInterface;
use CircleCRM\SSO\Server\AbstractServer;

/**
 * Server
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
class Server extends AbstractServer{
    
    public function getLoginUrl()
    {
        $url = sprintf("%s?service=%s",parent::getLoginUrl(),urlencode($this->getServiceId()));
        $this->log("Server::getLoginUrl() => ".$url);
        return $url;
    }
    
    public function getLogoutUrl()
    {
        $service = sprintf('service=%s', urlencode($this->getServiceId()));
        $url = $this->getLogoutRedirect() ? sprintf('&url=%s', urlencode($this->getLogoutRedirect())) : null;

        $logoutUrl = sprintf('%s?%s%s', parent::getLogoutUrl(), $service, $url);
        $this->log("Server::getLogoutUrl() => ".$logoutUrl);
        return $logoutUrl;
    }
    
    public function getValidationUrl()
    {
        $url = sprintf('%s?service=%s', parent::getValidationUrl(), urlencode($this->getServiceId()));
        $this->log("Server::getValidationUrl() => ".$url);
        return $url;
    }
    
    /**
     * 
     * @param mixed $credentials
     * @return RequestInterface
     */
    public function getValidationHttpRequest($credentials)
    {
        $url = sprintf("%s&ticket=%s",$this->getValidationUrl(),$credentials);
        $this->log("Server::getValidationHttpRequest() url => ".$url);
        
        return new Request($this->getValidationHttpMethod(), $url);
    }
    
    public function getAuthenticationHttpRequest($username, $secret)
    {
        return new Request($this->getAuthenticationMethod(), $this->getAuthenticationUrl());
    }
    
}
