<?php

/*
 * Copyright 2008-2014 Voiptech s.r.l.
 */

namespace CircleCRM\Cas\Validation;

use Psr\Http\Message\ResponseInterface;
use Psr\Log\LoggerInterface;
use Psr\Log\LogLevel;
use CircleCRM\SSO\Validation\AbstractValidation;

/**
 * BaseValidation
 *
 * @author <a href="mailto:gsantini@voiptech.it">Giorgio M. Santini</a>
 */
abstract class BaseValidation extends AbstractValidation
{
    /**
     *
     * @var LoggerInterface
     */
    private $logger;
    
    /**
     * 
     * @return LoggerInterface
     */
    public function getLogger()
    {
        return $this->logger;
    }
    
    /**
     * 
     * @param LoggerInterface $logger
     * @return $this
     */
    public function setLogger(LoggerInterface $logger = null)
    {
        $this->logger = $logger;
        return $this;
    }
    
    protected function log($message, $level = LogLevel::DEBUG, array $context = [])
    {
        if($this->getLogger()!=null)
        {
            $this->getLogger()->log($level, $message, $context);
        }
    }

}
